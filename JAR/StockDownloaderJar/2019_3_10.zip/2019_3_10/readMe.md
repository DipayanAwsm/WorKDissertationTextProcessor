/*	In this  program you are going 
 * 
 * arguments
 *  1.provide StockSymbolFile
 *  2.folder name and 
 *  3.file name
 *   and the code will store all the StockData
 *   on that file of that folder


*/
/////////////////////////////
StockSymbolFile looks like
Companyname,StockSymbool
eg:
InfoSys,INFI
